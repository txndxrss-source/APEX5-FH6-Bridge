# APEX 5 FH6 Adaptive Trigger Bridge — GUI v2
# APEX 5 FH6 Adaptive Trigger Bridge — GUI v2

> RU / EN — один README для пользователя и для публикации проекта.

---

# 🇷🇺 РУССКИЙ

## 1. Что это

Это локальный bridge для **Flydigi APEX 5 + Forza Horizon 6**, который принимает FH6 telemetry по UDP и управляет adaptive triggers APEX 5.

В комплекте:
- GUI без консоли;
- светлая и очень тёмная тема;
- 3 профиля: `soft`, `medium`, `hard`;
- редактирование всех параметров из GUI;
- сохранение каждого профиля в отдельный `.ini`;
- живой Dashboard;
- отдельное окно Sensors для второго монитора;
- запуск / остановка bridge;
- исходник trigger-core, который не меняется GUI-обвязкой.

### Важно

Закрой **Flydigi Space / Space Station** и другие программы, которые могут перехватывать APEX 5.

Bridge использует:
- FH6 UDP telemetry: `127.0.0.1:5300`;
- APEX 5 HID;
- `hidapi`.

Никакой виртуальный Xbox/DS controller GUI сам не создаёт.

---

## 2. Быстрый запуск

### Вариант A — самый простой

Дважды щёлкни:

`START_APEX5_GUI.bat`

Консоль bridge отдельно не показывается.

Если рядом уже лежит собранный:

`APEX5_FH6_GUI.exe`

launcher запустит его.

Если EXE ещё нет, launcher автоматически запустит GUI через `pythonw.exe` / `pyw.exe`.

### Требования для запуска из исходников

- Windows 10/11;
- Python 3.10+;
- `hidapi`.

Установка зависимости:

```bat
py -m pip install hidapi
```

`tkinter` обычно уже входит в стандартный Windows Python.

---

## 3. FH6 — telemetry

В Forza Horizon 6 включи Data Out / telemetry и укажи:

- IP: `127.0.0.1`
- Port: `5300`

Bridge ожидает FH6 **324-byte Car Dash / Horizon telemetry**.

Обычная схема:

```text
FH6
  │ UDP 127.0.0.1:5300
  ▼
APEX5 FH6 Bridge
  │
  ├── APEX 5 HID → RT/LT adaptive trigger
  └── GUI telemetry → Dashboard / Sensors
```

---

## 4. Профили

В GUI доступны:

- **Soft** — лёгкая нагрузка;
- **Medium** — средняя;
- **Hard** — сильная.

Профиль хранится в:

```text
profiles\soft.ini
profiles\medium.ini
profiles\hard.ini
```

Изменения из GUI сохраняются в соответствующий `.ini`.

Нажми **Save profile** после изменений.

---

# 5. RT — газ / правый триггер

RT имеет три независимых параметра сопротивления:

```ini
gas_base
gas_input
gas_rpm
```

Формула:

```text
RT resistance =
    gas_base
  + throttle_ratio × gas_input
  + rpm_ratio × gas_rpm
```

где:
- `throttle_ratio` = газ / 255;
- `rpm_ratio` = нормализованный RPM между idle и max RPM.

### `gas_base`

Постоянная базовая Race-сила RT.

Примеры:

```ini
gas_base = 0
```

→ RT свободный.

```ini
gas_base = 1
```

→ базовая Race-сила = `1`.

```ini
gas_base = 15
```

→ базовая Race-сила = `15`.

`r2_*` **не прибавляется к `gas_base`**.

### `gas_input`

Добавка сопротивления от нажатия газа.

Например:

```ini
gas_base = 10
gas_input = 20
```

При лёгком газе будет примерно `10 + небольшая доля 20`.

При полном газе — примерно `30` до учёта RPM.

### `gas_rpm`

Добавка сопротивления от оборотов:

```ini
gas_base = 10
gas_input = 10
gas_rpm = 10
```

На высоком RPM вклад `gas_rpm` стремится к полным `10`.

### RT vibration

Параметры:

```ini
r2_max_strength
r2_duty
r2_pressure
r2_freq_min
r2_freq_max
```

Они отвечают за **отдельную динамическую вибрацию RT**, а не за базовую Race-силу.

Частота RT vibration следует RPM.

---

# 6. LT — тормоз / левый триггер

Параметры:

```ini
brake_base
brake_input
brake_abs
handbrake_max
```

Основная формула тормоза:

```text
LT resistance =
    brake_base
  + brake_ratio × brake_input
  + ABS/slip × brake_abs
  + handbrake contribution
```

### `brake_base`

Постоянная базовая сила LT.

### `brake_input`

Увеличивает сопротивление при более сильном нажатии тормоза.

### `brake_abs`

Добавляет нагрузку при ABS / slip.

### `handbrake_max`

Максимальная добавка от ручника.

LT специально настроен более сильно, чем RT.

---

# 7. Вибрация LT

Параметры:

```ini
l2_max_strength
l2_duty
l2_pressure
l2_freq_min
l2_freq_max
```

Частота в основном следует ABS / tire slip.

При торможении также есть небольшой contribution от road effect.

---

# 8. Road effect

Параметры:

```ini
max_strength
drift_reduction
drift_multiplier
airborne_multiplier
road_speed_scale
airborne_susp_low
airborne_susp_high
airborne_wheel_votes
```

### `max_strength`

Максимальная сила road texture.

### `drift_reduction`

Насколько сильно road effect подавляется во время дрифта.

Больше значение = сильнее уменьшение.

### `drift_multiplier`

Минимальная доля road effect, которая остаётся во время дрифта.

### `airborne_multiplier`

Road effect в воздухе.

```ini
airborne_multiplier = 0
```

→ полностью отключить road effect в воздухе.

### `road_speed_scale`

Скорость, на которой road effect набирает полный масштаб.

Меньше число = road effect приходит на полную силу раньше.

### Airborne heuristic

FH6 packet не содержит простого универсального `isAirborne = true/false`.

Поэтому bridge использует комбинацию:
- normalized suspension travel;
- реального road-contact / surface signals;
- vote по колёсам.

Настройки:

```ini
airborne_susp_low
airborne_susp_high
airborne_wheel_votes
```

---

# 9. Recoil

Recoil работает **только на LT**.

RT recoil не используется.

Параметры:

```ini
enabled
brake_threshold
abs_threshold
strength
stroke
cooldown_ms
```

### `enabled`

```ini
true
```

или

```ini
false
```

### `brake_threshold`

Минимальное значение тормоза `0..255`, при котором recoil вообще может сработать.

### `abs_threshold`

Порог TireCombinedSlip / ABS proxy `0..1`.

### `strength`

Сила recoil.

### `stroke`

Ход recoil.

### `cooldown_ms`

Минимальный интервал между импульсами recoil.

---

# 10. Dashboard

В основном окне можно смотреть:

- Speed;
- RPM;
- Gear;
- Throttle;
- Brake;
- Handbrake;
- RT Force;
- LT Force;
- RT Hz;
- ABS Hz;
- Slip;
- Road;
- Rumble;
- G-force;
- Drift;
- Airborne;
- suspension FL/FR/RL/RR;
- состояние telemetry.

---

# 11. Второй монитор

Открой **Sensors**.

Окно предназначено для постоянного отображения на втором мониторе.

Там можно оставить большой Dashboard с датчиками и смотреть telemetry во время езды, не занимая основное окно управления профилями.

---

# 12. Настройка профиля — практический порядок

Для RT удобно начинать так:

```ini
gas_base = 0
gas_input = 0
gas_rpm = 0
```

Проверить, что RT свободен.

Затем:

```ini
gas_base = 5
```

и постепенно повышать.

После этого отдельно добавлять:

```ini
gas_input
gas_rpm
```

Так легче понять вклад каждого параметра.

Для вибрации отдельно изменяй:

```ini
r2_max_strength
r2_duty
r2_pressure
r2_freq_min
r2_freq_max
```

Для LT аналогично:

```ini
brake_base
brake_input
brake_abs
handbrake_max
```

а затем отдельно:

```ini
l2_max_strength
l2_duty
l2_pressure
l2_freq_min
l2_freq_max
```

---

# 13. Если после изменений ничего не меняется

1. Нажми **Save profile**.
2. Убедись, что выбран именно тот профиль.
3. Перезапусти bridge.
4. Закрой Flydigi Space / Space Station.
5. Проверь, что FH6 отправляет telemetry на `127.0.0.1:5300`.
6. Проверь Dashboard — Speed/RPM должны меняться.

---

# 14. Сборка настоящего EXE

Запусти:

`build_exe.bat`

Скрипт установит PyInstaller и соберёт:

```text
APEX5_FH6_GUI.exe
APEX5_FH6_Bridge.exe
```

Главный GUI EXE после сборки копируется в корень пакета.

После этого можно просто запускать:

`APEX5_FH6_GUI.exe`

или:

`START_APEX5_GUI.bat`

---

# 15. Что можно публиковать

В текущем пакете нет пользовательских логов, скриншотов, сохранённой telemetry, паролей, API keys, токенов или аккаунтных данных.

Я также убрал:
- `__pycache__`;
- старые дублирующие README;
- старые launcher-скрипты `run_gui.vbs` / `run_gui.bat`.

В исходниках используется только локальный адрес:

```text
127.0.0.1
```

и стандартные идентификаторы устройства / протокола.

Перед публикацией не добавляй в архив свои:
- логи;
- дампы;
- скриншоты с личными путями Windows;
- кастомные файлы конфигурации, если в них появятся персональные данные.

---

# 🇬🇧 ENGLISH

## 1. What this is

A local bridge for **Flydigi APEX 5 + Forza Horizon 6**.

It receives FH6 UDP telemetry and controls the APEX 5 adaptive triggers.

Included:
- console-free GUI;
- light and very dark themes;
- `soft / medium / hard` profiles;
- editing of all INI values;
- per-profile saving;
- live Dashboard;
- separate Sensors window for a second monitor;
- bridge Start / Stop;
- the working trigger core wrapped by the GUI.

Close **Flydigi Space / Space Station** or other software that may capture the controller.

The bridge uses:
- `127.0.0.1:5300` for FH6 telemetry;
- APEX 5 HID;
- `hidapi`.

---

## 2. Quick start

Double-click:

`START_APEX5_GUI.bat`

The launcher does not open the bridge console.

If `APEX5_FH6_GUI.exe` exists next to the launcher, it starts the EXE.

Otherwise it starts the GUI through `pythonw.exe` / `pyw.exe`.

For source-based launch you need:
- Windows 10/11;
- Python 3.10+;
- `hidapi`.

Install:

```bat
py -m pip install hidapi
```

---

## 3. FH6 telemetry

Set FH6 Data Out / telemetry to:

- IP: `127.0.0.1`
- Port: `5300`

The bridge expects the FH6 **324-byte Car Dash / Horizon telemetry** packet.

---

## 4. Profiles

Three profiles are included:

- `soft`
- `medium`
- `hard`

Saved as:

```text
profiles\soft.ini
profiles\medium.ini
profiles\hard.ini
```

GUI edits are saved to the selected profile.

---

## 5. RT / gas

RT resistance is controlled only by:

```ini
gas_base
gas_input
gas_rpm
```

Formula:

```text
RT =
    gas_base
  + throttle_ratio × gas_input
  + rpm_ratio × gas_rpm
```

`gas_base` is the permanent base Race force.

Examples:

```ini
gas_base = 0
```

RT is free.

```ini
gas_base = 1
```

Base Race force is `1`.

```ini
gas_base = 15
```

Base Race force is `15`.

RT vibration uses:

```ini
r2_max_strength
r2_duty
r2_pressure
r2_freq_min
r2_freq_max
```

These are separate from the `gas_*` resistance values.

---

## 6. LT / brake

Main LT resistance:

```ini
brake_base
brake_input
brake_abs
handbrake_max
```

LT is intentionally stronger than RT.

---

## 7. LT vibration

```ini
l2_max_strength
l2_duty
l2_pressure
l2_freq_min
l2_freq_max
```

ABS/slip mainly drives LT vibration frequency.

---

## 8. Road

```ini
max_strength
drift_reduction
drift_multiplier
airborne_multiplier
road_speed_scale
airborne_susp_low
airborne_susp_high
airborne_wheel_votes
```

These control road texture, drift suppression and the airborne heuristic.

---

## 9. Recoil

Recoil is **LT only**.

```ini
enabled
brake_threshold
abs_threshold
strength
stroke
cooldown_ms
```

RT recoil is never used.

---

## 10. Dashboard / Sensors

The main GUI shows live:
- speed;
- RPM;
- gear;
- throttle;
- brake;
- handbrake;
- RT/LT force;
- RT/ABS frequency;
- slip;
- road;
- rumble;
- G-force;
- drift;
- airborne;
- suspension values.

The separate Sensors window is intended for a second monitor.

---

## 11. Recommended tuning order

For a free RT, start with:

```ini
gas_base = 0
gas_input = 0
gas_rpm = 0
```

Then change only:

```ini
gas_base
```

After that tune:

```ini
gas_input
gas_rpm
```

For RT vibration tune separately:

```ini
r2_max_strength
r2_duty
r2_pressure
r2_freq_min
r2_freq_max
```

The same method can be used for LT.

---

## 12. Build the EXE

Run:

`build_exe.bat`

It builds:

```text
APEX5_FH6_GUI.exe
APEX5_FH6_Bridge.exe
```

The GUI EXE is copied to the package root.

Then you can launch:

`APEX5_FH6_GUI.exe`

or:

`START_APEX5_GUI.bat`

---

## 13. Public sharing / privacy

This cleaned package contains no user logs, screenshots, telemetry history, passwords, API keys, tokens, or account data.

The generated Python cache files were removed as well.

The only network endpoint hard-coded in the project is:

```text
127.0.0.1
```

Before publishing, do not add your own:
- logs;
- screenshots;
- crash dumps;
- custom files containing personal Windows paths.

---

## 14. Files

Main files:

```text
START_APEX5_GUI.bat     # normal launcher
APEX5_FH6_GUI.exe       # appears after build_exe.bat
apex5_gui.pyw            # GUI source
fh6_apex5_bridge.py      # trigger/telemetry core
bridge_worker.py         # bridge entry point
profiles\*.ini            # three profiles
build_exe.bat             # EXE builder
README.md                 # this document
```

## Windows EXE build note

This source package includes `BUILD_WINDOWS_EXE.bat`, which creates `release/APEX5_FH6_GUI.exe` and `release/APEX5_FH6_Bridge.exe` on Windows with one double-click.

A GitHub Actions workflow is also included at `.github/workflows/build-windows.yml` for automatic Windows builds in a repository.

The GUI/bridge trigger core is not rewritten by the build scripts; they only package the existing Python implementation.


## Portable EXE layout / Портативная структура

The GUI EXE uses the folder containing the EXE as its runtime directory. Keep `profiles\` and `APEX5_FH6_Bridge.exe` next to `APEX5_FH6_GUI.exe`.

GUI EXE использует папку, где лежит EXE, как рабочую директорию. Рядом с `APEX5_FH6_GUI.exe` должны лежать `APEX5_FH6_Bridge.exe` и папка `profiles\`. This fixes the blank Settings page and allows profile edits to persist outside the PyInstaller temporary extraction folder.
