# Public distribution / Публичная раздача

## Для автора проекта

Самый удобный вариант для пользователей — раздавать **`APEX5_FH6_Bridge_Setup.exe`**, а не исходники и не Python-папку.

Этот installer ставит самодостаточные PyInstaller EXE и профили. Пользователю не нужны:
- Python
- pip
- hidapi
- PyInstaller

Для сборки нужен только Windows build machine (или GitHub Actions).

### GitHub Actions — рекомендуемый способ

1. Залей репозиторий на GitHub.
2. В репозитории открой **Actions**.
3. Запусти workflow **Build Windows Portable + Installer** вручную, либо создай git tag вида `v2.1.0`.
4. Workflow выдаст:
   - `APEX5_FH6_Bridge_Setup.exe` — основной файл для пользователей;
   - portable build — резервный вариант.

### Что делает конечный пользователь

1. Скачать `APEX5_FH6_Bridge_Setup.exe`.
2. Запустить двойным кликом.
3. Установить.
4. Запустить ярлык **APEX 5 FH6 Bridge**.
5. Python/hidapi/pip вручную ставить не нужно.

Установщик работает без прав администратора: приложение ставится в `%LOCALAPPDATA%\Programs\APEX5FH6Bridge`.

## Важно

Обычно Windows Defender/SmartScreen может показывать предупреждение для нового неподписанного EXE. Это вопрос репутации/цифровой подписи, а не отсутствия Python-зависимостей. Для публичной раздачи стоит позже подписывать installer сертификатом Code Signing.

## Fresh Windows checklist

Проверять нужно на отдельной чистой Windows 10/11 x64 VM:

- нет Python;
- нет pip;
- нет hidapi;
- нет PyInstaller;
- запустить installer;
- открыть GUI;
- увидеть профили Soft/Medium/Hard;
- запустить bridge;
- проверить APEX 5;
- проверить FH6 UDP telemetry;
- проверить датчики и второй монитор.
